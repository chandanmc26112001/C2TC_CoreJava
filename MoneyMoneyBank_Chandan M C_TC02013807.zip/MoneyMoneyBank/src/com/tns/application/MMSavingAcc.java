package com.tns.application;

import com.tns.framework.SavingAcc;

public class MMSavingAcc extends SavingAcc{
	
	private static final float accBal = 1000;
	
	public MMSavingAcc(int accNo, String accNm, float accBal, boolean isSalary) {
		super(accNo, accNm, accBal, isSalary);
	}

	@Override
	public float getwithdraw() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public void withdraw(float accBal) {
		System.out.println("Dear Saving account user!! Your money is withdrawn and your account balance is " + accBal);
	}

	@Override
	public String toString() {
		return "MMSavingAcc [getwithdraw()=" + getwithdraw() + ", toString()=" + super.toString() + ", getAccNo()="
				+ getAccNo() + ", getAccNm()=" + getAccNm() + ", getAccBal()=" + getAccBal() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}

}

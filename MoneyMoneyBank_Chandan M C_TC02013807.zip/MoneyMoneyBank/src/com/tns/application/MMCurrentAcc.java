package com.tns.application;

import com.tns.framework.CurrentAcc;

public class MMCurrentAcc extends CurrentAcc{
	
	public MMCurrentAcc(int accNo, String accNm, float accBal, float creditLimit) {
		super(accNo, accNm, accBal, creditLimit);
	}
	
	@Override
	public float getwithdraw() {
		// TODO Auto-generated method stub
		return 0;
	}
 

	public void withdraw(float creditLimit) {
		System.out.println("Dear Current account user!! your money is withdrawn and your account balance is " + getAccBal() + " and Credit Limit is " + getCreditLimit());
	}

	@Override
	public String toString() {
		return "MMCurrentAcc [getCreditLimit()=" + getCreditLimit() + ", toString()=" + super.toString()
				+ ", getAccNo()=" + getAccNo() + ", getAccNm()=" + getAccNm() + ", getAccBal()=" + getAccBal()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}

}
